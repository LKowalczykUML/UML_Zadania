#include <iostream>
#include "../SchematB.h"

using namespace std;

int main()
{
    int n,k;
    double p;
    cin>>n>>k>>p;
    SchematB *SB = new SchematB(k,n,p);
    cout<<SB->getResult()<<endl;
    delete SB;
}
