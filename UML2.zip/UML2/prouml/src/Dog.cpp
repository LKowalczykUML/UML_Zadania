#include "Dog.h"

Dog::Dog()
{
    //ctor
}

Dog::~Dog()
{
    //dtor
}

void Dog::bark()
{
    cout<<"WOOF WOOF"<<endl;
}
