#include "Daschund.h"

Daschund::Daschund()
{
    //ctor
}

Daschund::~Daschund()
{
    //dtor
}
