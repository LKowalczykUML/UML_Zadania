#include "Animal.h"

Animal::Animal()
{
    //ctor
}

Animal::~Animal()
{
    //dtor
}
