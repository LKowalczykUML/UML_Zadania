#include "Mammal.h"

Mammal::Mammal()
{
    //ctor
}

Mammal::~Mammal()
{
    //dtor
}
