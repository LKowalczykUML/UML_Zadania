#ifndef MAMMAL_H
#define MAMMAL_H

#include <Animal.h>


class Mammal : public Animal
{
    public:
        Mammal();
        virtual ~Mammal();

    protected:

    private:
};

#endif // MAMMAL_H
