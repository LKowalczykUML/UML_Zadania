#ifndef DASCHUND_H
#define DASCHUND_H

#include <Dog.h>


class Daschund : public Dog
{
    public:
        Daschund();
        virtual ~Daschund();

    protected:

    private:
};

#endif // DASCHUND_H
