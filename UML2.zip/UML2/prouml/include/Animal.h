#ifndef ANIMAL_H
#define ANIMAL_H


class Animal
{
    public:
        Animal();
        virtual ~Animal();

    protected:

    private:
};

#endif // ANIMAL_H
