#ifndef DOG_H
#define DOG_H

#include <Mammal.h>


class Dog : public Mammal
{
    public:
        Dog();
        virtual ~Dog();
        void bark();

    protected:

    private:
};

#endif // DOG_H
