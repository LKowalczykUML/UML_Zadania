#include "TLibrary.h"
#include<iostream>

TLibrary::TLibrary(std::string n)
{
    libraryName=n;
}

TLibrary::~TLibrary()
{
    delete book;
}

void TLibrary::setData(std::string title,std::string mark)
{
    book = new TBook();
    book->setShelfMark(mark);
    book->setTitle(title);
}

void TLibrary::printData()
{
    std::cout<<book->getTitle()<<" : "<<book->getShelfMark()<<std::endl;
}
