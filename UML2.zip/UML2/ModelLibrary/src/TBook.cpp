#include "TBook.h"

TBook::TBook()
{
    //ctor
}

TBook::~TBook()
{
    //dtor
}


void TBook::setTitle(std::string t)
{
    bookTitle=t;
}
std::string TBook::getTitle()
{
    return bookTitle;
}
void TBook::setShelfMark(std::string m)
{
    shelfMark=m;
}
std::string TBook::getShelfMark()
{
    return shelfMark;
}

