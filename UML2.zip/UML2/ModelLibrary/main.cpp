#include <iostream>
#include "TLibrary.h"
using namespace std;

int main()
{
    TLibrary* lib =new TLibrary("biblio");
    lib->setData("Zatrute pioro","Kryminal");
    lib->printData();
}
