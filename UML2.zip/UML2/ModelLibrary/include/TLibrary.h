#ifndef TLIBRARY_H
#define TLIBRARY_H

#include "TBook.h"

class TLibrary
{
    public:
        TLibrary(std::string);
        virtual ~TLibrary();
        void setData(std::string title,std::string mark);
        void printData();
    protected:

    private:
        TBook* book;
        std::string libraryName;
};

#endif // TLIBRARY_H
