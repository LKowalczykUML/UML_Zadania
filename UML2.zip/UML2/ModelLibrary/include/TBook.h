#ifndef TBOOK_H
#define TBOOK_H
#include "string"

class TBook
{
    public:
        TBook();
        virtual ~TBook();
        void setTitle(std::string);
        std::string getTitle();
        void setShelfMark(std::string);
        std::string getShelfMark();

    protected:

    private:
        std::string bookTitle;
        std::string shelfMark;
};

#endif // TBOOK_H
