#include "TStudent.h"
#include "string"

TStudent::TStudent()
{
    //ctor
}

TStudent::~TStudent()
{
    //dtor
}

void TStudent::setName(std::string n)
{
    Name=n;
}

void TStudent::setAge(int a)
{
    Age=a;
}

std::string TStudent::getName()
{
    return Name;
}

int TStudent::getAge()
{
    return Age;
}
