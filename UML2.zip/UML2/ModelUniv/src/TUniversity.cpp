#include "TUniversity.h"
#include<iostream>

TUniversity::TUniversity(std::string uniName)
{
    Name=uniName;
}

TUniversity::~TUniversity()
{
    //dtor
}

void TUniversity::setData(std::string name,int age)
{
    Student.setAge(age);
    Student.setName(name);
}

void TUniversity::printData()
{
    std::cout<<Student.getName()<<" : "<<Student.getAge()<<std::endl;
}
