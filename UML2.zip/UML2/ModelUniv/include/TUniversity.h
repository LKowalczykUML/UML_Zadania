#ifndef TUNIVERSITY_H
#define TUNIVERSITY_H

#include "TStudent.h"
#include "string"

class TUniversity
{
    public:
        TUniversity(std::string);
        virtual ~TUniversity();
        void setData(std::string name,int age);
        void printData();
    protected:

    private:
        TStudent Student;
        std::string Name;
};

#endif // TUNIVERSITY_H
