#ifndef TSTUDENT_H
#define TSTUDENT_H

#include "string"

class TStudent
{
    public:
        TStudent();
        virtual ~TStudent();
        void setName(std::string);
        void setAge(int);
        std::string getName();
        int getAge();

    protected:

    private:
        std::string Name;
        int Age;
};

#endif // TSTUDENT_H
