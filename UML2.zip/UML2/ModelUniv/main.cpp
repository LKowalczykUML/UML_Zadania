#include <iostream>
#include "TUniversity.h"

using namespace std;

int main()
{
    TUniversity *UMCS=new TUniversity("UMCS");
    UMCS->setData("Lukasz",22);
    UMCS->printData();
}
